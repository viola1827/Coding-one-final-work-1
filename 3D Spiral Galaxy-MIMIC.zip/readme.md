

            Mac OSX
            Open Terminal
            Run python libs/server.py
            Open Browser, go to localhost:4201

            Windows
            Open Command Prompt
            Run python libs/server.py
            Open Browser, go to localhost:4201

            